# Backup de clase: replicar modelo unificado sin fallar

## Objetivo
Crear un modelo estable con:
- `Fact Ventas`
- `Dim Producto Unificada`
- `Dim Fecha`
- (Opcional) `Tec DateTemplate` oculta

y evitar el error clasico de borrar tablas fuente antes de independizar la consulta M.

## Archivos de apoyo
Usar este archivo como origen:
- `3_Demo_Modelo_Fragmentado.xlsx`

## Flujo recomendado (seguro)
1. Abrir `3_Demo_Modelo_Fragmentado.xlsx` en Power BI Desktop (Import).
2. Verificar que existen tablas de origen fragmentadas:
   - `TRX_SALES_RAW`
   - `STG_ITEM_CATALOG`
   - `LKP_CAT_L2`
   - `LKP_CAT_L1`
   - `REF_BRAND_MASTER`
3. Renombrar tablas (opcional pero recomendado):
   - `TRX_SALES_RAW` -> `Fact Ventas`
   - `STG_ITEM_CATALOG` -> `Dim Producto`
   - `LKP_CAT_L2` -> `Dim Subcategoria`
   - `LKP_CAT_L1` -> `Dim Categoria`
   - `REF_BRAND_MASTER` -> `Dim Marca`
4. Crear nueva consulta `Dim Producto Unificada` en Power Query.
5. Pegar el script M (seccion siguiente) para que la consulta sea AUTOSUFICIENTE.
6. Cerrar y aplicar.
7. Crear/validar relacion activa:
   - `Fact Ventas[ID_Producto]` (muchos) -> `Dim Producto Unificada[ID_Producto]` (uno)
8. Validar con una visual de tabla: `Nombre_Producto`, `Nombre_Categoria`, `Nombre_Marca`.
9. Solo despues de validar, eliminar tablas antiguas:
   - `Dim Producto`, `Dim Subcategoria`, `Dim Categoria`, `Dim Marca`

## Script M seguro (autosuficiente)
Copiar en la consulta `Dim Producto Unificada`:

```powerquery
let
    Origen = Excel.Workbook(File.Contents("C:\\Users\\Usuario\\Desktop\\Cursos\\15_CIRCE_2026\\Clase 3\\Modelado\\3_Demo_Modelo_Fragmentado.xlsx"), null, true),

    STG_ITEM_CATALOG_Sheet = Origen{[Item="STG_ITEM_CATALOG",Kind="Sheet"]}[Data],
    ProductoPromoted = Table.PromoteHeaders(STG_ITEM_CATALOG_Sheet, [PromoteAllScalars=true]),
    ProductoTipo = Table.TransformColumnTypes(ProductoPromoted,{{"ID_Producto", type text}, {"Nombre_Producto", type text}, {"ID_Subcategoria", type text}, {"ID_Marca", type text}, {"Precio_EUR", Int64.Type}}),

    LKP_CAT_L2_Sheet = Origen{[Item="LKP_CAT_L2",Kind="Sheet"]}[Data],
    SubcatPromoted = Table.PromoteHeaders(LKP_CAT_L2_Sheet, [PromoteAllScalars=true]),
    SubcatTipo = Table.TransformColumnTypes(SubcatPromoted,{{"ID_Subcategoria", type text}, {"Nombre_Subcategoria", type text}, {"ID_Categoria", type text}}),

    LKP_CAT_L1_Sheet = Origen{[Item="LKP_CAT_L1",Kind="Sheet"]}[Data],
    CatPromoted = Table.PromoteHeaders(LKP_CAT_L1_Sheet, [PromoteAllScalars=true]),
    CatTipo = Table.TransformColumnTypes(CatPromoted,{{"ID_Categoria", type text}, {"Nombre_Categoria", type text}}),

    REF_BRAND_MASTER_Sheet = Origen{[Item="REF_BRAND_MASTER",Kind="Sheet"]}[Data],
    MarcaPromoted = Table.PromoteHeaders(REF_BRAND_MASTER_Sheet, [PromoteAllScalars=true]),
    MarcaTipo = Table.TransformColumnTypes(MarcaPromoted,{{"ID_Marca", type text}, {"Nombre_Marca", type text}, {"Pais_Origen", type text}}),

    MergeSubcategoria = Table.NestedJoin(ProductoTipo, {"ID_Subcategoria"}, SubcatTipo, {"ID_Subcategoria"}, "Subcat", JoinKind.LeftOuter),
    ExpandSubcategoria = Table.ExpandTableColumn(MergeSubcategoria, "Subcat", {"Nombre_Subcategoria", "ID_Categoria"}, {"Nombre_Subcategoria", "ID_Categoria"}),

    MergeCategoria = Table.NestedJoin(ExpandSubcategoria, {"ID_Categoria"}, CatTipo, {"ID_Categoria"}, "Cat", JoinKind.LeftOuter),
    ExpandCategoria = Table.ExpandTableColumn(MergeCategoria, "Cat", {"Nombre_Categoria"}, {"Nombre_Categoria"}),

    MergeMarca = Table.NestedJoin(ExpandCategoria, {"ID_Marca"}, MarcaTipo, {"ID_Marca"}, "Marca", JoinKind.LeftOuter),
    ExpandMarca = Table.ExpandTableColumn(MergeMarca, "Marca", {"Nombre_Marca", "Pais_Origen"}, {"Nombre_Marca", "Pais_Origen"}),

    Resultado = Table.SelectColumns(ExpandMarca,{"ID_Producto", "Nombre_Producto", "ID_Subcategoria", "Nombre_Subcategoria", "ID_Categoria", "Nombre_Categoria", "ID_Marca", "Nombre_Marca", "Pais_Origen", "Precio_EUR"})
in
    Resultado
```

## Check rapido de integridad
- `Dim Producto Unificada` carga sin error.
- Hay relacion activa con `Fact Ventas` por `ID_Producto`.
- Una visual por `Nombre_Categoria` muestra importes.
- No hay campos con advertencia amarilla/roja en modelo.

## Error tipico y solucion
Error tipico:
- `La importacion Dim Producto no coincide con ninguna exportacion`

Causa:
- La unificada sigue referenciando consultas/tablas borradas.

Solucion:
- Reemplazar su M por el script autosuficiente de arriba.
- Aplicar cambios.
- Refrescar.

## Plan B para clase (2 minutos)
Si algo falla en directo:
1. No borrar nada.
2. Duplicar el PBIX antes de tocar.
3. Recrear solo `Dim Producto Unificada` con el script.
4. Validar relacion con `Fact Ventas`.
5. Continuar clase con esa tabla, y limpieza al final.
